<html>
  <head>
    <title>Pere Comments </title>
  </head>
<body>
<?php
  echo "<h3>List</h3>
        <ul>
        <li>I'v learned to pass variables between pages</li>
        <li>There are 2 methods to pass variables. First is \$_GET and second \$_POST</li>
        <li>This methods are used to pass variables in url's or forms</li>
        <li>With the function session_start() we can leave opened the session</li>
        <li>The variable sessions is usefull to save data about the user's login </li>
        <li>The urlencode() function works to change a string in a URL code</li>
        <li>Function date() has a lot of subfuncions </li>
        <li>Setcookie() is for saving user's temporary data on the browser</li>
        <li>Spaceship is an operator that compare 2 values and It returns -1,0 or 1 </li>
        <li>On the if/else statements we can use ? or ?? to make it shortest. </li>
  
  </ul>
  <p>Document: 7</p>
  <p>Teacher: 10</p>
  <p>Myself: 5</p>
  <p>Improvemts: I don't know what improvements could make easier to learn this but I know that I would need improve myself in php. ";
?>
</body>
</html>
